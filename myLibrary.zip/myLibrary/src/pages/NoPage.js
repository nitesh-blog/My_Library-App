import React from 'react';

const NoPage = () => {
    return (
        <div style={{textAlign:"center",margin:"70px"}}>
        <h1>OOPs { 404 } :(</h1>
        <h3>Error: Page Not Found !</h3>
        </div>
    );
}

export default NoPage;
