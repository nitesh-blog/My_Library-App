import {Outlet,Link} from "react-router-dom";
import "./Layout.css";

const Layout = () =>{
    return (
        <>
       
        <nav>
        <ul>
     <li className="leftside">My Library</li>
     <li>
      <Link to="/create">Add a new book</Link>
      </li>
      <li>
        <Link to ="/">Home</Link>
      </li>
     
    </ul>
        </nav>
        <Outlet />
        </>
    )
};

export default Layout;