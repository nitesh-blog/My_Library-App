import React from "react";
import ReactDom from "react-dom/client";
import "./AddBook.css";

function AddBook()
{
    return(
        <>
        <h2 className="font-change">Add a New Book</h2>
    <form>
       
        <label>Title:</label> <br/>
        <input type="text" placeholder="Enter the title of the book" />
        <br/>
        
        <label>Autor:</label> <br/>
        <input type="text" placeholder="Enter the name of the author of the book" />
        <br/>

        <label>Year:</label> <br/>
        <input type="number" placeholder="Enter the year in which the book was written" />
        <br/>

        <label>ISBN:</label> <br/>
        <input type="number" placeholder="Enter the ISBN number of the book" />
        <br/>

        <label>Cover Image URL:</label> <br/>
        <input type="text"  placeholder="Enter the URL for the cover image of the book"/>
        <br/>

        <label>Blurb:</label> <br/>
        <textarea rows="10" />
    </form>

        </>

    );
}

export default AddBook;