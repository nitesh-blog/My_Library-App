import React from 'react';
import ReactDOM from 'react-dom/client';
import AddBook from './AddBook';

function Home()
{
    return <h1>Home Page</h1>
}

export default Home;